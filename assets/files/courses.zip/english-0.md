
#### <font color="#6425d0">English</font><br><font color="#6425d0">Irregular Verbs</font>
###### +

This concise course helps learners memorize the most common English irregular verbs.
Through flashcards, you'll master past tense and past participle forms effortlessly.
The course consists of five levels, from level <font color="#f79646">A1</font> to level <font color="#f79646">C1</font> and covers <font color="#f79646">126</font> verbs in <font color="#f79646">14</font> lessons.
###### ++
# @a1

###### English Irregular Verbs
##### A1: Elementary
###### +

Elementary level contains 123 verbs
###### ++
# @@lesson-1

###### English Irregular Verbs<br>A1: Elementary
##### Lesson # 1

BE, BUY, COME, CUT, DO, DRINK, EAT, GET, GO,HAVE, HEAR, LEARN, LEAVE, LET, MEET, PUT, READ, RUN
###### /button-da /da/english-0-0001
###### /button-t /t/english-0-0001
###### ++
# @@lesson-2

###### English Irregular Verbs<br>A1: Elementary
##### Lesson # 2

SAY, SEE, SEND, SET, SHOW, SING, SIT, SLEEP, SPEAK, STAND, SWIM, TAKE, TEACH, THINK, UNDERSTAND, WRITE
###### /button-da /da/english-0-0002
###### /button-t /t/english-0-0002
###### ++
# @a2

###### English Irregular Verbs
##### A2: Lower Intermediate
###### +

Lower Intermediate level contains 123 verbs
###### ++
# @@lesson-3

###### English Irregular Verbs<br>A2: Lower Intermediate
##### Lesson # 3

BECOME, BEGIN, BREAK, BRING, BUILD, BURN, CATCH, COOSE, COST, DRAW, DREAM, DRIVE
###### /button-da /da/english-0-0003
###### /button-t /t/english-0-0003
###### ++
# @@lesson-4

###### English Irregular Verbs<br>A2: Lower Intermediate
##### Lesson # 4

FALL, FEEL, FIND, FLY, FORGET, GIVE, GROW, HIT, HOLD, HURT, KEEP, KNOW
###### /button-da /da/english-0-0004
###### /button-t /t/english-0-0004
###### ++
# @@lesson-5

###### English Irregular Verbs<br>A2: Lower Intermediate
##### Lesson # 5

LAY, LIE, LEND, LOSE, MAKE, MEAN, PAY, QUIT, RING, RIDE, RISE
###### /button-da /da/english-0-0005
###### /button-t /t/english-0-0005
###### ++
# @@lesson-6

###### English Irregular Verbs<br>A2: Lower Intermediate
##### Lesson # 6

SELL, SHAVE, SHOOT, SMELL, SPELL, SPEND, STEAL, TELL, THROW, WAKE UP, WEAR, WIN
###### /button-da /da/english-0-0006
###### /button-t /t/english-0-0006
###### ++
# @b1

###### English Irregular Verbs
##### B1: Intermediate
###### +

Intermediate level contains 123 verbs
###### ++
# @@lesson-7

###### English Irregular Verbs<br>B1: Intermediate
##### Lesson # 7

BEAR, BEAT, BEND, BET, BITE, BIND, BLEED, BROADCAST, BURST, DEAL
###### /button-da /da/english-0-0007
###### /button-t /t/english-0-0007
###### ++
# @@lesson-8

###### English Irregular Verbs<br>B1: Intermediate
##### Lesson # 8

FIGHT, FLEE, FORBID, FORGIVE, HIDE, LEAD, LEAN, LEAP, LIE, PROVE
###### /button-da /da/english-0-0008
###### /button-t /t/english-0-0008
###### ++
# @@lesson-9

###### English Irregular Verbs<br>B1: Intermediate
##### Lesson # 9

SEEK, SHAKE, SHINE, SHRINK, SHUT, SINK, SPOIL, STINK, STRIKE, SWEAR, SWELL, TEAR, THRUST
###### /button-da /da/english-0-0009
###### /button-t /t/english-0-0009
###### ++
# @b2

###### English Irregular Verbs
##### B2: Upper Intermediate
###### +

Upper Intermediate level contains 123 verbs
###### ++

# @@lesson-10

###### English Irregular Verbs<br>B2: Upper Intermediate
##### Lesson # 10

ARISE, BLOW, BID, BREED, CAST, CREEP, DIG, FEED, FREEZE, HANG, LIGHT, MOW, OVERCOME
###### /button-da /da/english-0-0010
###### /button-t /t/english-0-0010
###### ++
# @@lesson-11

###### English Irregular Verbs<br>B2: Upper Intermediate
##### Lesson # 11

SAW, SLIDE, SOW, SPILL, SPREAD, TREAD, UNDERGO, UNDERTAKE, WEEP
###### /button-da /da/english-0-0011
###### /button-t /t/english-0-0011
###### ++
# @c1

###### English Irregular Verbs
##### C1: Advanced
###### +

Advanced Level contains 123 verbs
###### ++

# @@lesson-12

###### English Irregular Verbs<br>C1: Advanced
##### Lesson # 12

ABIDE BY, AWAKE, BEHOLD, CLING, DWELL, FLING, FORECAST, FORSWEAR, GRIND, KNEEL, KNIT
###### /button-da /da/english-0-0012
###### /button-t /t/english-0-0012
###### ++
# @@lesson-13

###### English Irregular Verbs<br>C1: Advanced
##### Lesson # 13

SEW, SHED, SLAY, SPEED, SPIN, SPIT, SPLIT, SPRING, STICK, STING, STREW, STRIDE, SWEEP, SWING
###### /button-da /da/english-0-0013
###### /button-t /t/english-0-0013
###### ++
# @@lesson-14

###### English Irregular Verbs<br>C1: Advanced
##### Lesson # 14

THRIVE, UPSET, WEAVE, WET, WITHDRAW, WITHHOLD, WITHSTAND, WRING
###### /button-da /da/english-0-0014
###### /button-t /t/english-0-0014
###### ++