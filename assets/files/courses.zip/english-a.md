
#### <font color="#6425d0">Essential Grammar</font><br><font color="#6425d0">In Use</font>
###### <font color="#4f81bd">from Understanding to Fluency</font>
###### +
<font color="#c00000">Important Note</font>:

This is an independent educational supplement.
We strongly recommend purchasing the original "<font color="#c00000">Essential Grammar in Use 3rd Edition</font>" for the complete theoretical foundation and authoritative examples.
This course is designed to enhance, not replace, that experience.
###### ++
# @unit-1

###### Essential Grammar in Use
##### Unit 1
###### +
Essential Grammar in Use, Unit 1
Lessons 1, 2
###### /button-da /da/english-a-0002
###### /button-g /g/english-a-0002
###### /button-t /t/english-a-0002

###### ++
# @@lesson-1

###### Essential Grammar in Use<br>Unit 1
##### Lesson # 1

Тут описание урока 1
###### ++
# @@lesson-2
###### Essential Grammar in Use<br>Unit 1
##### Lesson # 2

Lesson 2
###### ++
# @unit-2

###### Essential Grammar in Use
##### Unit 2
###### +
Essential Grammar in Use, Unit 2
Lessons 3, 4
Тут содержится всякое разное про юниты
###### ++
# @@lesson-3
###### Essential Grammar in Use<br>Unit 2
##### Lesson # 3

Lesson1
###### ++
# @@lesson-4
###### Essential Grammar in Use<br>Unit 1
##### Lesson # 4

Lesson 2
###### ++